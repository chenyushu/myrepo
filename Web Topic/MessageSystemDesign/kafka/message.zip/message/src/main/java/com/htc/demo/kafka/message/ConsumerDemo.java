package com.htc.demo.kafka.message;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;
import kafka.message.MessageAndMetadata;

public class ConsumerDemo {

    private static ConsumerConfig createConsumerConfig(String a_zookeeper,
            String a_groupId) {
        Properties props = new Properties();
        props.put("zookeeper.connect", a_zookeeper);
        props.put("group.id", a_groupId);
        props.put("auto.commit.interval.ms", "1000");
        props.put("offsets.storage", "kafka");
        //props.put("offsets.storage", "zookeeper");
        props.put("dual.commit.enabled", "false");
        
        // if chat room only two man, then can set smallest
        props.put("auto.offset.reset", "smallest");

        return new ConsumerConfig(props);
    }

    public static void main(String[] args) {
        String topic = "chatroom1";

        ConsumerConfig consumerConfig = createConsumerConfig(
                "master:2181,slave1:2181,deeptheming.htcsense.com.local:2181",
                "user6");
        ConsumerConnector consumerConnector = Consumer
                .createJavaConsumerConnector(consumerConfig);
        

        
        System.out.println("consumerConnector create");

        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put(topic, 1);

        Map<String, List<KafkaStream<byte[], byte[]>>> topicMessageStreams = consumerConnector
                .createMessageStreams(map);
        List<KafkaStream<byte[], byte[]>> streams = topicMessageStreams.get(topic);
        
        KafkaStream<byte[], byte[]> stream = streams.get(0);
        
        ExecutorService executor = Executors.newFixedThreadPool(1);
        executor.submit(new ConsumerTest(stream));
        
        
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ie) {
         
        }
        
//        consumerConnector.shutdown();
//        executor.shutdown();
        
        System.out.println("finish");
        


        // create list of 4 threads to consume from each of the partitions
//        ExecutorService executor = Executors.newFixedThreadPool(4);
//
//        // consume the messages in the threads
//        for (final KafkaStream<Message> stream : streams) {
//            executor.submit(new Runnable() {
//                public void run() {
//                    for (MessageAndMetadata<Message> msgAndMetadata : stream) {
//                        // process message (msgAndMetadata.message())
//                        System.out.println(msgAndMetadata.message());
//                    }
//                }
//            });
//        }

    }
    
    private static class ConsumerTest implements Runnable {
        private KafkaStream<byte[], byte[]> m_stream;
     
        public ConsumerTest(KafkaStream<byte[], byte[]> a_stream) {
            m_stream = a_stream;
        }
     
        public void run() {
            ConsumerIterator<byte[], byte[]> it = m_stream.iterator();
            while(it.hasNext()) {
                MessageAndMetadata<byte[], byte[]>  message = it.next();
                System.out.println(String.format("User:[%s], Message:[%s]", new String(message.key()), new String(message.message())));
            }
   
        }
    }

}
