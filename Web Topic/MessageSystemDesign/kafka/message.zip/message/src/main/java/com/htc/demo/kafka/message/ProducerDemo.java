package com.htc.demo.kafka.message;

import java.util.Properties;
import java.util.Random;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;


/**
 * Hello world!
 *
 */
public class ProducerDemo {
    public static void main( String[] args ) {
            Properties props = new Properties();
            props.put("bootstrap.servers", "master:9092,slave1:9092,deeptheming.htcsense.com.local:9092");
            props.put("producer.type", "sync");
            props.put("acks", "1");
            props.put("compression.type", "lz4");
            props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            props.put("client.id", "ProducerDemo");
     
            KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);
     
            // ProducerRecord(java.lang.String topic, K key, V value) 
            ProducerRecord<String, String> record = new ProducerRecord<String, String>("chatroom1", "user1", "I am good good?");
            
            producer.send(record, new Callback(){

                public void onCompletion(RecordMetadata data, Exception e) {
                    if(data != null) {
                        System.out.println(String.format("topic: %s", data.topic()));
                        System.out.println(String.format("Partition %d", data.partition()));
                        System.out.println(String.format("offset: %d", data.offset()));
                    } else {
                        e.printStackTrace();
                    }
                    
                }
                
            });
            
            producer.close();
    }
}
