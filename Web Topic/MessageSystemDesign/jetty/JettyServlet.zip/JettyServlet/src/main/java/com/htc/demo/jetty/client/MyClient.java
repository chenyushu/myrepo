package com.htc.demo.jetty.client;

import java.io.IOException;
import java.net.URI;
import java.util.Calendar;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketClose;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketError;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import org.eclipse.jetty.websocket.client.ClientUpgradeRequest;
import org.eclipse.jetty.websocket.client.WebSocketClient;

public class MyClient {
    public static void main(String[] args) throws Exception {
        
        URI destUri = new URI("ws://localhost:8080/JettyServlet-0.0.1-SNAPSHOT/wsexample");

        WebSocketClient client = new WebSocketClient();
        MyWebSocket socket = new MyWebSocket();
        
        try {
            client.start();
            ClientUpgradeRequest request = new ClientUpgradeRequest();
            
            System.out.printf("Connecting to : %s%n", destUri);
            
            client.connect(socket, destUri, request);
            
            socket.awaitClose(5, TimeUnit.SECONDS);
        } catch (Throwable t) {
            t.printStackTrace();
        } finally {
            try {
                MessageThread thread = new MessageThread(socket.m_session);
                //thread.start();
                //client.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private static class MessageThread extends Thread {
        private Session mSession;
        
        public MessageThread(Session session) {
            mSession = session;
        }
        
        public void run(){
            while(true) {
                try {
                    if(mSession.isOpen()) {
                        mSession.getRemote().sendString("Client: " + Calendar.getInstance().toString());
                        Thread.sleep(5000);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    @WebSocket
    public static class MyWebSocket {
        public Session m_session = null; 
    
        private final CountDownLatch closeLatch = new CountDownLatch(1);

        @OnWebSocketConnect
        public void onConnect(Session session) throws IOException {
            m_session = session;
            
            System.out.println("Sending message: Hello server");
            session.getRemote().sendString("Hello server");
            
            
        }

        @OnWebSocketMessage
        public void onMessage(String message) {
            System.out.println("Message from Server: " + message);
        }

        @OnWebSocketClose
        public void onClose(int statusCode, String reason) {
            System.out.println("WebSocket Closed. Code:" + statusCode);
            System.out.println("WebSocket Closed. Reasion:" + reason);
            this.closeLatch.countDown();
        }
        
        @OnWebSocketError
        public void onError(Session session, Throwable t) {
            System.out.println("Error remote: " + session.getRemoteAddress().getAddress());
            System.out.println("Error: " + t.getMessage());
        }

        public boolean awaitClose(int duration, TimeUnit unit) 
                throws InterruptedException {
            return this.closeLatch.await(duration, unit);
        }
    }
}
