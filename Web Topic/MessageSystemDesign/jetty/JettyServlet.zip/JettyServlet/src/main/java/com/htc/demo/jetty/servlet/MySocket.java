package com.htc.demo.jetty.servlet;

import java.io.IOException;
import java.util.Calendar;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.WriteCallback;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketClose;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketError;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketFrame;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import org.eclipse.jetty.websocket.api.extensions.Frame;

@WebSocket
public class MySocket {

    @OnWebSocketClose
    public void onClose(Session session, int statusCode, String reason) {
        System.out.println("Close remote: "
                + session.getRemoteAddress().getAddress());

        // refer
        // http://download.eclipse.org/jetty/stable-9/apidocs/org/eclipse/jetty/websocket/api/StatusCode.html
        System.out.println("status code: " + statusCode);
        System.out.println("Close: " + reason);
    }

    @OnWebSocketError
    public void onError(Session session, Throwable t) {
        System.out.println("Error remote: "
                + session.getRemoteAddress().getAddress());
        System.out.println("Error: " + t.getMessage());

    }

    @OnWebSocketConnect
    public void onConnect(Session session) {
        System.out.println("Local address: "
                + session.getLocalAddress().getAddress());
        System.out.println("Connect: "
                + session.getRemoteAddress().getAddress());

        System.out.println("Session isOpen: "
                + Boolean.toString(session.isOpen()));
        System.out.println("Session isSecure: "
                + Boolean.toString(session.isSecure()));

        System.out.println("idle timeout: "
                + session.getPolicy().getIdleTimeout());

        System.out.println("MaxBinaryMessageBufferSize: "
                + session.getPolicy().getMaxBinaryMessageBufferSize());
        System.out.println("MaxBinaryMessageSize: "
                + session.getPolicy().getMaxBinaryMessageSize());
        System.out.println("MaxTextMessageBufferSize: "
                + session.getPolicy().getMaxTextMessageBufferSize());
        System.out.println("MaxTextMessageSize: "
                + session.getPolicy().getMaxTextMessageSize());

    }

    @OnWebSocketMessage
    public void onMessage(Session session, String message) {
        System.out.println("Send remote: "
                + session.getRemoteAddress().getAddress());
        System.out.println("Message: " + message);

        System.out.println("Hello webbrowser");
        session.getRemote().sendString("Hello Webbrowser", new WriteCallback() {

            @Override
            public void writeFailed(Throwable e) {
                System.out.println(e.getMessage());

            }

            @Override
            public void writeSuccess() {
                System.out.println("Message sucess");

            }
        });

        MessageThread serverMessage = new MessageThread(session);
        serverMessage.start();
    }

    @OnWebSocketMessage
    public void onMessage(Session session, byte[] buf, int offset, int length) {
        System.out.println("Send remote: "
                + session.getRemoteAddress().getAddress());
        System.out.println("Message: " + new String(buf));
    }

    // @OnWebSocketFrame
    // public void onFrame(Session session, Frame frame) {
    // System.out.println("Frame remote: " +
    // session.getRemoteAddress().getAddress());
    // System.out.println("Payload length:" + frame.getPayloadLength());
    // }

    private static class MessageThread extends Thread {
        private Session mSession;

        public MessageThread(Session session) {
            mSession = session;
        }

        public void run() {
            while (true) {
                try {
                    if (mSession.isOpen()) {
                        mSession.getRemote().sendString(
                                "Server: " + Calendar.getInstance().toString());

                        Thread.sleep(5000);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
