/************************************************************************************

Filename    :   BitmapFont.h
Content     :   Bitmap font rendering.
Created     :   March 11, 2014
Authors     :   Jonathan E. Wright

Copyright   :   Copyright 2014 Oculus VR, LLC. All Rights reserved.

*************************************************************************************/

#if !defined( OVR_BitmapFont_h )
#define OVR_BitmapFont_h

#include "LibOVR/Src/Kernel/OVR_Math.h"

namespace OVR {

class BitmapFont;
class BitmapFontSurface;


// To get a black outline on fonts, AlphaCenter should be < ( ColorCenter = 0.5 )
// To get non-outlined fonts, ColorCenter should be < ( AlphaCenter = 0.5 )
struct fontParms_t {
    fontParms_t() :
        CenterHoriz( false ),
        CenterVert( false ),
		Billboard( false ),
		TrackRoll( false ),
		AlphaCenter( 0.425f ),
		ColorCenter( 0.50f )
    {
    }

    bool    CenterHoriz;    // center horizontally around the specified x coordinate
    bool    CenterVert;     // center vertically around the specified y coordinate
	bool	Billboard;		// true to always face the camera
	bool	TrackRoll;		// when billboarding, track with camera roll
	float   AlphaCenter;	// below this distance, alpha is 0, above this alpha is 1
	float	ColorCenter;	// blow this distance, color is 0, above this color is 1
};

//==============================================================
// BitmapFont
class BitmapFont
{
public:
    static BitmapFont *     Create();
    static void             Free( BitmapFont * & font );

    virtual bool   	        Load( char const * fontInfoFileName ) = 0;
    virtual bool            LoadFromBuffers( unsigned char const * fontInfoBuffer, size_t const fontInfoBufferSize,
					                unsigned char const * imageBuffer, size_t const imageBufferSize ) = 0;
    // Calculates the native (unscaled) width of the text string. Line endings are ignored.
    virtual float           CalcTextWidth( char const * text ) const = 0;
    // Calculates the native (unscaled) width of the text string. Each '\n' will start a new line
	// and will increase the height by FontInfo.FontHeight. For multi-line strings, lineWidths will 
	// contain the width of each individual line of text and width will be the width of the widest
	// line of text.
	virtual void	        CalcTextMetrics( char const * text, size_t & len, float & width, float & height,
									float & ascent, float & descent, float * lineWidths, int const maxLines, int & numLines ) const = 0;

protected:
    virtual ~BitmapFont() { }
};

//==============================================================
// BitmapFontSurface
class BitmapFontSurface
{
public:
    static  BitmapFontSurface * Create();
    static  void                Free( BitmapFontSurface * & fontSurface );

    virtual void        Init( const int maxVertices ) = 0;
	virtual void		DrawText3D( BitmapFont const & font, const fontParms_t & flags,
						        const Vector3f & pos, Vector3f const & normal, Vector3f const & up,
						        float const scale, Vector4f const & color, char const * text ) = 0;
	virtual void		DrawText3Df( BitmapFont const & font, const fontParms_t & flags,
						        const Vector3f & pos, Vector3f const & normal, Vector3f const & up,
						        float const scale, Vector4f const & color, char const * text, ... ) = 0;

	virtual void		DrawTextBillboarded3D( BitmapFont const & font, fontParms_t const & flags,
						        Vector3f const & pos, float const scale, Vector4f const & color, 
                                char const * text ) = 0;
	virtual void		DrawTextBillboarded3Df( BitmapFont const & font, fontParms_t const & flags,
						        Vector3f const & pos, float const scale, Vector4f const & color, 
                                char const * fmt, ... ) = 0;

	virtual void		Finish( Matrix4f const & viewMatrix ) = 0;

	virtual void		Render3D( BitmapFont const & font, Matrix4f const & worldMVP ) = 0;

protected:
    virtual     ~BitmapFontSurface() { }
};


}   // namespace OVR

#endif // OVR_BitmapFont_h
