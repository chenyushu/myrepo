/************************************************************************************

Filename    :   OVR_Win32_SensorDevice.h
Content     :   Win32 SensorDevice implementation
Created     :   March 12, 2013
Authors     :   Lee Cooper

Copyright   :   Copyright 2014 Oculus VR, LLC. All Rights reserved.

*************************************************************************************/

#ifndef OVR_Win32_SensorDevice_h
#define OVR_Win32_SensorDevice_h

namespace OVR { namespace Win32 {

}} // namespace OVR::Win32

#endif // OVR_Win32_SensorDevice_h

